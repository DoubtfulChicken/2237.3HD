package org.example.assignmenttracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
