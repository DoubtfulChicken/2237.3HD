package org.example.assignmentapp.controller;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.assignmentapp.model.Assignment;

public class TaskContextMenu {

    private TableView<Assignment> assignmentTable;

    public TaskContextMenu(TableView<Assignment> assignmentTable) {
        this.assignmentTable = assignmentTable;  // Pass the reference to the TableView
    }

    public ContextMenu createContextMenu(TableRow<Assignment> row, Stage stage) {
        ContextMenu contextMenu = new ContextMenu();

        // Add "Copy", "Edit", "Delete" options
        MenuItem copyItem = new MenuItem("Copy");
        copyItem.setOnAction(e -> copyTask(row.getItem()));

        MenuItem editItem = new MenuItem("Edit");
        editItem.setOnAction(e -> editTask(row.getItem()));

        MenuItem deleteItem = new MenuItem("Delete");
        deleteItem.setOnAction(e -> deleteTask(row.getItem()));

        // Add "Set Unit Colour" option
        MenuItem setUnitColorItem = new MenuItem("Change Unit Colour");
        setUnitColorItem.setOnAction(e -> openColorPickerForUnit(row.getItem(), stage));

        // Add "Set Grade Colour" option
        MenuItem setGradeColorItem = new MenuItem("Change Grade Colour");
        setGradeColorItem.setOnAction(e -> openColorPickerForGrade(row.getItem(), stage));

        // Add "Change Status" option
        MenuItem changeStatusItem = new MenuItem("Change Status");
        changeStatusItem.setOnAction(e -> changeStatus(row.getItem()));

        // Add items to context menu
        contextMenu.getItems().addAll(copyItem, editItem, deleteItem, setUnitColorItem, setGradeColorItem, changeStatusItem);

        return contextMenu;
    }

    private void copyTask(Assignment assignment) {
        // Implement the logic to copy the task
    }

    private void editTask(Assignment assignment) {
        // Implement the logic to edit the task
    }

    private void deleteTask(Assignment assignment) {
        // Implement the logic to delete the task
    }

    public void openColorPickerForUnit(Assignment assignment, Stage stage) {
        ColorPicker colorPicker = new ColorPicker();
        VBox vbox = new VBox(colorPicker);
        Scene scene = new Scene(vbox);
        Stage colorPickerStage = new Stage();
        colorPickerStage.setScene(scene);
        colorPickerStage.initStyle(StageStyle.UTILITY);
        colorPickerStage.initModality(Modality.APPLICATION_MODAL);
        colorPickerStage.showAndWait();

        // When the color is picked, apply it to all rows with the same unit code
        Color selectedColor = colorPicker.getValue();
        for (Assignment rowAssignment : assignmentTable.getItems()) {
            if (rowAssignment.getUnitCode().equals(assignment.getUnitCode())) {
                rowAssignment.setRowColor(selectedColor);  // Set the selected color
            }
        }

        // Refresh the table view to reflect changes
        assignmentTable.refresh();  // This ensures the table is re-rendered
    }

    private void openColorPickerForGrade(Assignment assignment, Stage parentStage) {
        Stage colorStage = new Stage();
        ColorPicker colorPicker = new ColorPicker();
        VBox vbox = new VBox(colorPicker);
        Scene scene = new Scene(vbox, 200, 100);
        colorStage.setScene(scene);
        colorStage.initOwner(parentStage);
        colorStage.show();

        colorPicker.setOnAction(event -> {
            Color selectedColor = colorPicker.getValue();
            setGradeColorForAll(assignment.getGrade(), selectedColor);
            assignmentTable.refresh();  // Refresh table to reflect color change
            colorStage.close();  // Close color picker window
        });
    }

    // Update unit color for all assignments with the same unit code
    private void setUnitColorForAll(String unitCode, Color color) {
        String hexColor = toHexString(color);
        for (Assignment assignment : assignmentTable.getItems()) {
            if (assignment.getUnitCode().equals(unitCode)) {
                assignment.setUnitColor(hexColor);
            }
        }
    }

    // Update grade color for all assignments with the same grade
    private void setGradeColorForAll(String grade, Color color) {
        String hexColor = toHexString(color);
        for (Assignment assignment : assignmentTable.getItems()) {
            if (assignment.getGrade().equals(grade)) {
                assignment.setGradeBorderColor(hexColor);
            }
        }
    }


    private void changeStatus(Assignment assignment) {
        // Implement the logic to change the task status
    }

    // Helper method to convert Color to hex string
    private String toHexString(Color color) {
        return String.format("#%02X%02X%02X", (int) (color.getRed() * 255), (int) (color.getGreen() * 255), (int) (color.getBlue() * 255));
    }
}